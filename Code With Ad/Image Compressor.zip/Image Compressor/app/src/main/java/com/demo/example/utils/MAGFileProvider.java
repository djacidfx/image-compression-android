package com.demo.example.utils;

import androidx.core.content.FileProvider;



public class MAGFileProvider extends FileProvider {
}
