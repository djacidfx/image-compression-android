package com.demo.example.interfaces;

import android.view.View;



public interface ItemClickListener {
    void onItemClick(View view, int i);
}
