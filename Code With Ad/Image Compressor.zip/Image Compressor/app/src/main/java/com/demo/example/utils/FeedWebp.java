package com.demo.example.utils;



public class FeedWebp {
    String myfiles;
    Float size;
    String title;

    public Float getSize() {
        return this.size;
    }

    public void setSize(Float f) {
        this.size = f;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public String getMyfiles() {
        return this.myfiles;
    }

    public void setMyfiles(String str) {
        this.myfiles = str;
    }
}
